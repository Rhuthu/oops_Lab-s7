package B200767CS_1;
import java.util.*;

class Q5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        //declares an array
        int[] array;
        System.out.print("Size of array,n= ");
        int n=sc.nextInt();
        //allocates memory for array
        array=new int[n];
        int temp=0;

        for(int i=0;i<n;i++){
            array[i]=sc.nextInt();
        }

        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                if(array[i]>array[j]){
                    temp=array[i];
                    array[i]=array[j];
                    array[j]=temp;
                }

            }
        }
        for(int i=0;i<n;i++){
            System.out.print(array[i]+" ");
        }


        
        


    }
    
}

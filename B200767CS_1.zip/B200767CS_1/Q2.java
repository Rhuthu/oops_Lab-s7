package B200767CS_1;
import java.util.*;

class Q2 {
    public static void main(String[] args) {

      Scanner sc=new Scanner(System.in);
      System.out.print("a= ");
      int a=sc.nextInt();
      System.out.print("b= ");
      int b=sc.nextInt();

      a=a+b;
      b=a-b;
      a=a-b;
      System.out.println("a= "+a+" b= "+b);
      
      
    }
    
}

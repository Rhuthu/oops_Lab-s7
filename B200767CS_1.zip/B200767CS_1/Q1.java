package B200767CS_1;

import java.util.*;
import java.lang.Math;
class Q1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the base of the number: ");
        int n=sc.nextInt();
        System.out.print("Enter the Exponent ");
        int exp=sc.nextInt();
         System.out.println(Math.pow(n, exp));



    }
}

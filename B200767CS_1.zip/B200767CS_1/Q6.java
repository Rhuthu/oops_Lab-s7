package B200767CS_1;
import java.util.*;

 class Q6 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int org=sc.nextInt();
        int rev=0;
        int num=org;

        while(num>0){
        
            rev=rev*10+num%10;
            num=num/10;

        }
        if(org==rev){
            System.out.println("True");
        }else{
            System.out.println("False");
        }
    }
    
}

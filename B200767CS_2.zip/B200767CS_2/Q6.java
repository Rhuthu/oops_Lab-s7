package B200767CS_2;
import java.util.*;
//Find second Largest element in an Array

public class Q6 {
   public static void printSecondLargest(int array[],int size){
    //atleat 2 elements needed
    if(size<2){
        System.out.println("Invalid");
        return;
    }
    //sort the array
    Arrays.sort(array);
    //last element is the largest element , so start from second last
    for(int i=size-2;i>=0;i--){
        if(array[i]!=array[size-1]){
            System.out.println(array[i]);
            return;
        }
    }
   }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        int array[]=new int[size];
        //input
        for(int i=0;i<size;i++){
            array[i]=sc.nextInt();
        }
        printSecondLargest(array, size);
    }
    
}

package B200767CS_2;
import java.util.*;
// find if a number is a palindrome or not. Take number as parameter.

 class Q1 {

    public static void palindromeCheck(int num){
        int org=num;
        int rev=0;
        while(num>0){
            rev=rev*10+num%10;
            num=num/10;
        }
        if(org==rev){
            System.out.println("True");
        }else{
            System.out.println("False");
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        palindromeCheck(num);
    }
    
}

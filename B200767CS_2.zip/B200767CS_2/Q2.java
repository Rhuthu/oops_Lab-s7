package B200767CS_2;
import java.util.*;
//e a function that returns all prime numbers between two given numbers. 

 class Q2 {

    public static boolean printPrime(int n){ //to check prime or not
    
       if(n<=1){
        return false;
       }
       for(int i=2;i<=n/2;i++){
        if(n%i==0){
            return false;
        }
       }
        return true;
        }

        public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            int a=sc.nextInt();//lower bound
            int b=sc.nextInt();//upper bound
            for(int i=a;i<=b;i++){
                if(printPrime(i)){
            System.out.print(i+" ");
                }
            }
        }
        
    }
    
    


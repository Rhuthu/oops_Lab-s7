package B200767CS_2;
import java.util.*;

//Given a sorted array return the index of given key. 
class Q4 {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int size=sc.nextInt();
       
        int numbers[]=new int[size];

        //input
        for(int i=0;i<size;i++){
            numbers[i]=sc.nextInt();
        }
        Arrays.sort(numbers);//sort the array
         int key=sc.nextInt();
        //output
          for(int i=0;i<numbers.length;i++){
            if(numbers[i]==key){
                 System.out.println("element found at index "+i);
            }
            
          }
        

    }
    
}

package B200767CS_2;
import java.util.*;
// Given two matrices, multiply them.

 class Q5 {
   public static void printMatrix(int m[][],int r,int c){
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
            System.out.print(m[i][j]+" ");
        }
        System.out.println();
    }
   }
   public static void multiplyMatrix(int m1[][],int m2[][],int r1,int c1,int r2,int c2){
    //new matrix for storing values
    if(r2!=c1){ //checking compatiblility
        System.out.println("Multiplication not possible");
    }else{
    int m[][]=new int[r1][c2];
    for(int i=0;i<r1;i++){
        for(int j=0;j<c2;j++){
            for(int k=0;k<r2;k++){
                m[i][j]+=m1[i][k]*m2[k][j];
            }
        }
    }
    System.out.println("Resultant matrix");
    //for each loop
    for (int[] row: m) { //iterate through each row in the 2d array
        for (int column : row) { //iterate through each column in the current row
            System.out.print(column+" ");//print current column element
            
        }
        System.out.println();
    }
}
   }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int row1=sc.nextInt();
        int cols1=sc.nextInt();
        int matrix1[][]=new int[row1][cols1];
        //matrix 1 input
        for(int i=0;i<row1;i++){
            for(int j=0;j<cols1;j++){
                matrix1[i][j]=sc.nextInt();
            }
        }
        //output matrix 1
        System.out.println("matrix 1");
        printMatrix(matrix1, row1, cols1);

        //input matrix 2
        int row2=sc.nextInt();
        int cols2=sc.nextInt();
        int matrix2[][]=new int[row2][cols2];
        for(int i=0;i<row2;i++){
            for(int j=0;j<cols2;j++){
                matrix2[i][j]=sc.nextInt();
            }
        }
        //output matrix 2
        System.out.println("matrix 2");
        printMatrix(matrix2, row2, cols2);
       multiplyMatrix(matrix1, matrix2, row1,  row2, cols1,cols2);

        
    }
    
}

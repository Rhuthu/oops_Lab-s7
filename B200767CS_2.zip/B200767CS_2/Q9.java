package B200767CS_2;
import java.util.*;

//Check given two strings are equivalent or not

class Q9 {
    public static boolean compareString(String str1,String str2){
        if(str1.equals(str2)){
            return true;
        }else{
            return false;
        }
    }

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String str1=sc.nextLine();
        String str2=sc.nextLine();
        if(compareString(str1, str2)){
            System.out.println("strings are equivalent");
        }else{
            System.out.println("Strings are not equivalent");
        }
    }
    
}

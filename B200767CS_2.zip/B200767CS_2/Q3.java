package B200767CS_2;
import java.util.*;
//Write a function that returns the sum of first n natural numbers. 
 class Q3 {
    public static int sumOfNaturalNumbers(int n){
        return n*(n+1)/2;
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        System.out.println(sumOfNaturalNumbers(n));
    }
    
}

package B200767CS_2;
import java.util.*;
//Given a string s, return the string after replacing every uppercase letter with the same lowercase 
//letter.

 class Q7 {
    public static String replaceLetter(String str){
        StringBuilder result=new StringBuilder();
        for(int i=0;i<str.length();i++){
                char c=str.charAt(i);
                if(Character.isUpperCase(c)){
                    result.append(Character.toLowerCase(c));
                }else{
                    result.append(c);
                }
        }
        return result.toString();
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("input:");
        String str=sc.nextLine();
        //to replace the letter, create new string 
        String result=replaceLetter(str);
        System.out.println("output:"+result);

    }
    
}

package B200767CS_2;
import java.util.*;
// java program to reverse a string 

 class Q8 {
    public static String reverseString(String str){
        StringBuilder reverse=new StringBuilder();
        for(int i=str.length()-1;i>=0;i--){
            reverse.append(str.charAt(i));
        }
        return reverse.toString();
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Input: ");
        String str=sc.nextLine();
        String Result=reverseString(str);
        System.out.println("Output: "+Result);

    }
    
}
